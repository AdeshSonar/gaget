<?php

namespace App\Controllers\Zone;

use App\Controllers\BaseController;
use App\Models\CircularModel;
use App\Models\CircularVersionModel;
use App\Models\CircularWorkflowEventModel;
use App\Models\DocumentTypeModel;
use App\Models\EmployeeModel;

class CircularController extends BaseController
{
    public function create()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('zone_office')) {
            return redirect()->to('/dashboard');
        }

        $docTypes   = (new DocumentTypeModel())->where('is_active', 1)->orderBy('name', 'ASC')->findAll();
        $employees  = (new EmployeeModel())->where('is_active', 1)->orderBy('full_name', 'ASC')->findAll();

        return view('zone/circulars/create', [
            'title'     => 'Create Draft Circular',
            'docTypes'  => $docTypes,
            'employees' => $employees,
        ]);
    }

    public function index()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('zone_office')) {
            return redirect()->to('/dashboard');
        }

        $db = db_connect();

        $rows = $db->table('circulars c')
            ->select('c.id, c.title, c.status, c.created_at, c.submitted_at, dt.name as document_type')
            ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
            ->where('c.origin_office_id', (int) ($user->office_id ?? 0))
            ->orderBy('c.id', 'DESC')
            ->get()
            ->getResultArray();

        return view('zone/circulars/index', [
            'title'     => 'My Circulars (Zone)',
            'circulars' => $rows,
        ]);
    }

    public function submit($id)
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('zone_office')) {
            return redirect()->to('/dashboard');
        }

        $id = (int) $id;
        $db = db_connect();

        $c = $db->table('circulars')
            ->where('id', $id)
            ->get()
            ->getRowArray();

        if (! $c) {
            return redirect()->back()->with('error', 'Circular not found.');
        }

        if ((int) $c['origin_office_id'] !== (int) ($user->office_id ?? 0)) {
            return redirect()->back()->with('error', 'Not allowed.');
        }

        if ($c['status'] !== 'DRAFT') {
            return redirect()->back()->with('error', 'Only DRAFT circulars can be submitted.');
        }

        $now = date('Y-m-d H:i:s');

        $db->transStart();

        $db->table('circulars')
            ->where('id', $id)
            ->update([
                'status'       => 'IN_REVIEW',
                'submitted_at' => $now,
                'submitted_by' => (int) $user->id,
                'updated_at'   => $now,
            ]);

        $db->table('circular_workflow_events')->insert([
            'circular_id'         => $id,
            'event_type'          => 'SUBMITTED',
            'from_status'         => 'DRAFT',
            'to_status'           => 'IN_REVIEW',
            'actor_user_id'       => (int) $user->id,
            'actor_office_id'     => (int) ($user->office_id ?? null),
            'circular_version_id' => $c['current_version_id'] ? (int) $c['current_version_id'] : null,
            'ip_address'          => $this->request->getIPAddress(),
            'user_agent'          => (string) $this->request->getUserAgent(),
            'notes'               => 'Submitted for admin review',
            'created_at'          => $now,
        ]);

        $db->transComplete();

        if (! $db->transStatus()) {
            return redirect()->back()->with('error', 'Submit failed.');
        }

        return redirect()->to('/zone/circulars')->with('success', 'Submitted for review.');
    }

    public function store()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('zone_office')) {
            return redirect()->to('/dashboard');
        }

        $post = $this->request->getPost([
            'document_type_id',
            'title',
            'template_key',
        ]);

        $recipientIds = $this->request->getPost('recipient_ids') ?? [];
        if (! is_array($recipientIds)) {
            $recipientIds = [];
        }

        // Normalize template key
        $templateKey = trim((string) ($post['template_key'] ?? ''));
        if ($templateKey === '') {
            $templateKey = 'transfer_v1';
        }

        // Build payload_json (template-driven)
        $payload = [
            'template_key'   => $templateKey,
            'subject'        => trim((string) $this->request->getPost('payload_subject')),
            'body'           => trim((string) $this->request->getPost('payload_body')),
            'effective_date' => (string) $this->request->getPost('payload_effective_date'),
        ];

        $db  = db_connect();
        $now = date('Y-m-d H:i:s');

        $db->transStart();

        // 1) Create circular
        $circularModel = new CircularModel();
        $circularId = $circularModel->insert([
            'document_type_id' => (int) $post['document_type_id'],
            'origin_office_id' => (int) ($user->office_id ?? 0),
            'status'           => 'DRAFT',
            'title'            => (string) $post['title'],
            'visibility'       => 'INTERNAL',
            'created_at'       => $now,
            'updated_at'       => $now,
        ], true);

        // 2) Create version 1
        $versionModel = new CircularVersionModel();
        $versionId = $versionModel->insert([
            'circular_id'     => (int) $circularId,
            'version_no'      => 1,
            'source'          => 'BUILDER',
            'template_key'    => $templateKey,
            'payload_json'    => json_encode($payload, JSON_UNESCAPED_UNICODE),
            'status_snapshot' => 'DRAFT',
            'created_by'      => (int) $user->id,
            'created_at'      => $now,
        ], true);

        // 3) Set current_version_id on circular
        $circularModel->update($circularId, [
            'current_version_id' => (int) $versionId,
            'updated_at'         => $now,
        ]);

        // 4) Insert recipients for this version (pivot table - use builder)
        $rows = [];
        foreach ($recipientIds as $eid) {
            $rows[] = [
                'circular_version_id' => (int) $versionId,
                'employee_id'         => (int) $eid,
                'created_at'          => $now,
            ];
        }

        if (! empty($rows)) {
            $db->table('circular_version_recipients')->insertBatch($rows);
        }

        // 5) Workflow event
        $eventModel = new CircularWorkflowEventModel();
        $eventModel->insert([
            'circular_id'         => (int) $circularId,
            'event_type'          => 'CREATED',
            'from_status'         => null,
            'to_status'           => 'DRAFT',
            'actor_user_id'       => (int) $user->id,
            'actor_office_id'     => (int) ($user->office_id ?? null),
            'circular_version_id' => (int) $versionId,
            'ip_address'          => $this->request->getIPAddress(),
            'user_agent'          => (string) $this->request->getUserAgent(),
            'notes'               => 'Draft created',
            'created_at'          => $now,
        ]);

        $db->transComplete();

        if (! $db->transStatus()) {
            return redirect()->back()->with('error', 'Failed to create draft.');
        }

        return redirect()->to('/zone/circulars')->with('success', 'Draft circular created.');
    }
}
