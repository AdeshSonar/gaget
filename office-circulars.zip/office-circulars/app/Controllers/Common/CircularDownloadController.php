<?php

namespace App\Controllers\Common;

use App\Controllers\BaseController;

class CircularDownloadController extends BaseController
{
    public function download($id)
    {
        helper('auth');

        $id = (int) $id;
        $db = db_connect();

        $c = $db->table('circulars')->where('id', $id)->get()->getRowArray();
        if (! $c) {
            return redirect()->back()->with('error', 'Circular not found.');
        }

        if ($c['status'] !== 'PUBLISHED' || (int) $c['is_void'] === 1) {
            return redirect()->back()->with('error', 'Not available for download.');
        }

        $versionId = (int) ($c['latest_published_version_id'] ?? 0);
        if ($versionId <= 0) {
            return redirect()->back()->with('error', 'No published version found.');
        }

        $v = $db->table('circular_versions')->where('id', $versionId)->get()->getRowArray();
        if (! $v || empty($v['pdf_path'])) {
            return redirect()->back()->with('error', 'PDF not generated yet.');
        }

        $fullPath = WRITEPATH . $v['pdf_path'];
        return $this->response->download($fullPath, null);
    }
}
