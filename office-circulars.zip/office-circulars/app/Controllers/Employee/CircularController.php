<?php

namespace App\Controllers\Employee;

use App\Controllers\BaseController;

class CircularController extends BaseController
{
public function myCirculars()
{
    helper('auth');

    $user = auth()->user();
    if (! $user->inGroup('employee')) {
        return redirect()->to('/dashboard');
    }

    $employeeRefId = (int) ($user->employee_ref_id ?? 0);
    if ($employeeRefId <= 0) {
        return view('employee/circulars/my', [
            'title'     => 'My Circulars',
            'circulars' => [],
            'note'      => 'Your account is not mapped to an employee record. Please contact admin.',
        ]);
    }

    $db = db_connect();

    $rows = $db->table('circulars c')
        ->select('c.id, c.title, c.published_at, dt.name as document_type, o.name as origin_office')
        ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
        ->join('offices o', 'o.id = c.origin_office_id', 'left')
        ->join('circular_version_recipients r', 'r.circular_version_id = c.latest_published_version_id', 'inner')
        ->where('c.status', 'PUBLISHED')
        ->where('c.is_void', 0)
        ->where('r.employee_id', $employeeRefId)
        ->orderBy('c.published_at', 'DESC')
        ->get()
        ->getResultArray();

    return view('employee/circulars/my', [
        'title'     => 'My Circulars',
        'circulars' => $rows,
        'note'      => null,
    ]);
}


    public function publishedCirculars()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('employee')) {
            return redirect()->to('/dashboard');
        }

        $db = db_connect();

        $rows = $db->table('circulars c')
            ->select('c.id, c.title, c.published_at, dt.name as document_type, o.name as origin_office')
            ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
            ->join('offices o', 'o.id = c.origin_office_id', 'left')
            ->where('c.status', 'PUBLISHED')
            ->where('c.is_void', 0)
            ->orderBy('c.published_at', 'DESC')
            ->get()
            ->getResultArray();

        return view('employee/circulars/published', [
            'title'     => 'All Published Circulars',
            'circulars' => $rows,
        ]);
    }
}
