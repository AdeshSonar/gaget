<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $user = auth()->user();

        $role = 'employee';
        if ($user && $user->inGroup('admin')) {
            $role = 'admin';
        } elseif ($user && $user->inGroup('zone_office')) {
            $role = 'zone_office';
        }

        return view('dashboard', [
            'title' => 'Dashboard',
            'user'  => $user,
            'role'  => $role,
        ]);
    }
}
