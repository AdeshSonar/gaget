<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\OfficeModel;

class OfficeController extends BaseController
{
    public function index()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

       $db = db_connect();

        $rows = $db->table('offices o')
            ->select('o.id, o.office_type, o.code, o.name, o.parent_id, o.is_active, p.name as parent_name, p.code as parent_code')
            ->join('offices p', 'p.id = o.parent_id', 'left')
            ->orderBy('o.office_type', 'ASC')
            ->orderBy('o.name', 'ASC')
            ->get()
            ->getResultArray();

        return view('admin/offices/index', [
            'title'   => 'Offices',
            'offices' => $rows,
        ]);

    }

    public function create()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $model = new OfficeModel();

        // Parent candidates: HQ offices (or all offices if you prefer)
        $parents = $model->where('is_active', 1)
                 ->orderBy('office_type', 'ASC')
                 ->orderBy('name', 'ASC')
                 ->findAll();

        // $parents = $model->where('office_type', 'HQ')
        //                  ->where('is_active', 1)
        //                  ->orderBy('name', 'ASC')
        //                  ->findAll();

        return view('admin/offices/create', [
            'title'   => 'Add Office',
            'parents' => $parents,
        ]);
    }

    public function store()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $data = $this->request->getPost([
            'office_type',
            'code',
            'name',
            'parent_id',
        ]);

        // Normalize empty parent to null
        $data['parent_id'] = empty($data['parent_id']) ? null : (int) $data['parent_id'];

        $model = new OfficeModel();
        $model->insert($data);

        return redirect()
            ->to('/admin/offices')
            ->with('success', 'Office added');
    }
}
