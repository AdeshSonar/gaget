<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class CircularAdminController extends BaseController
{
    public function index()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $db = db_connect();

        $rows = $db->table('circulars c')
            ->select('c.id, c.title, c.status, c.created_at, c.submitted_at, c.published_at, c.latest_published_version_id,
                      dt.name as document_type, o.name as origin_office,
                      v.pdf_path')
            ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
            ->join('offices o', 'o.id = c.origin_office_id', 'left')
            ->join('circular_versions v', 'v.id = c.latest_published_version_id', 'left')
            ->orderBy('c.id', 'DESC')
            ->get()
            ->getResultArray();

        return view('admin/circulars/index', [
            'title'     => 'All Circulars',
            'circulars' => $rows,
        ]);
    }
}
