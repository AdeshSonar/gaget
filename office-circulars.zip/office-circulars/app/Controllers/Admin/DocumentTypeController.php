<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\DocumentTypeModel;

class DocumentTypeController extends BaseController
{
    public function index()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $model = new DocumentTypeModel();

        return view('admin/document_types/index', [
            'title' => 'Document Types',
            'types' => $model->orderBy('name')->findAll(),
        ]);
    }

    public function create()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        return view('admin/document_types/create', [
            'title' => 'Add Document Type',
        ]);
    }

    public function store()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $data = $this->request->getPost([
            'code',
            'name',
        ]);

        $model = new DocumentTypeModel();
        $model->insert($data);

        return redirect()
            ->to('/admin/document-types')
            ->with('success', 'Document type added');
    }
}
