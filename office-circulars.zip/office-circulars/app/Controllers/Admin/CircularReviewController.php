<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class CircularReviewController extends BaseController
{
    public function index()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $db = db_connect();

        $rows = $db->table('circulars c')
            ->select('c.id, c.title, c.status, c.submitted_at, dt.name as document_type, o.name as origin_office')
            ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
            ->join('offices o', 'o.id = c.origin_office_id', 'left')
            ->where('c.status', 'IN_REVIEW')
            ->orderBy('c.submitted_at', 'DESC')
            ->get()
            ->getResultArray();

        return view('admin/review_queue/index', [
            'title'     => 'Review Queue',
            'circulars' => $rows,
        ]);
    }

    public function publish($id)
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $id = (int) $id;
        $db = db_connect();

        $c = $db->table('circulars')->where('id', $id)->get()->getRowArray();
        if (! $c) {
            return redirect()->back()->with('error', 'Circular not found.');
        }

        if ($c['status'] !== 'IN_REVIEW') {
            return redirect()->back()->with('error', 'Only IN_REVIEW circulars can be published.');
        }

        $now = date('Y-m-d H:i:s');

        $db->transStart();

        $db->table('circulars')
            ->where('id', $id)
            ->update([
                'status'                     => 'PUBLISHED',
                'published_at'               => $now,
                'published_by'               => (int) $user->id,
                'latest_published_version_id'=> $c['current_version_id'] ? (int) $c['current_version_id'] : null,
                'updated_at'                 => $now,
            ]);

        $db->table('circular_workflow_events')->insert([
            'circular_id'         => $id,
            'event_type'          => 'PUBLISHED',
            'from_status'         => 'IN_REVIEW',
            'to_status'           => 'PUBLISHED',
            'actor_user_id'       => (int) $user->id,
            'actor_office_id'     => (int) ($user->office_id ?? null),
            'circular_version_id' => $c['current_version_id'] ? (int) $c['current_version_id'] : null,
            'ip_address'          => $this->request->getIPAddress(),
            'user_agent'          => (string) $this->request->getUserAgent(),
            'notes'               => 'Published by admin',
            'created_at'          => $now,
        ]);

        $db->transComplete();

        if (! $db->transStatus()) {
            return redirect()->back()->with('error', 'Publish failed.');
        }

        return redirect()->to('/admin/review-queue')->with('success', 'Circular published.');
    }
}
