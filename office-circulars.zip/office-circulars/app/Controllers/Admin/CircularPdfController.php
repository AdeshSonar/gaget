<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Services\PdfService;

class CircularPdfController extends BaseController
{
    public function generate($id)
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $id = (int) $id;
        $db = db_connect();

        $c = $db->table('circulars c')
            ->select('c.*, dt.name as document_type, o.name as origin_office, u.username as published_username')
            ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
            ->join('offices o', 'o.id = c.origin_office_id', 'left')
            ->join('users u', 'u.id = c.published_by', 'left')
            ->where('c.id', $id)
            ->get()
            ->getRowArray();

        if (! $c) {
            return redirect()->back()->with('error', 'Circular not found.');
        }

        if ($c['status'] !== 'PUBLISHED') {
            return redirect()->back()->with('error', 'Only PUBLISHED circulars can generate PDF.');
        }

        $versionId = (int) ($c['latest_published_version_id'] ?? 0);
        if ($versionId <= 0) {
            return redirect()->back()->with('error', 'No published version found.');
        }

        $recipientsCount = $db->table('circular_version_recipients')
            ->where('circular_version_id', $versionId)
            ->countAllResults();

        // Load version row + payload
        $vrow = $db->table('circular_versions')->where('id', $versionId)->get()->getRowArray();
        if (! $vrow) {
            return redirect()->back()->with('error', 'Published version record not found.');
        }

        $payload = [];
        $tplKey  = null;

        if (! empty($vrow['payload_json'])) {
            $payload = json_decode($vrow['payload_json'], true) ?: [];
            $tplKey  = $payload['template_key'] ?? ($vrow['template_key'] ?? null);
        } else {
            $tplKey = $vrow['template_key'] ?? null;
        }

        // Template resolution
        $config = config('CircularTemplates'); // requires app/Config/CircularTemplates.php
        $tplMeta = (is_object($config) && !empty($tplKey) && isset($config->templates[$tplKey]))
            ? $config->templates[$tplKey]
            : null;

        $view = $tplMeta['view'] ?? 'pdf/circular_basic';

        // Watermark rules: published -> none
        $watermarkText = null;

        $html = view($view, [
            'payload' => $payload,
            'meta' => [
                'title'            => $c['title'],
                'document_type'    => $c['document_type'] ?? '',
                'origin_office'    => $c['origin_office'] ?? '',
                'published_by'     => $c['published_username'] ?? 'admin',
                'published_at'     => $c['published_at'] ?? '',
                'circular_no'      => $c['circular_no'] ?? null,
                'recipients_count' => $recipientsCount,
            ],
            'watermark_text' => $watermarkText,
        ]);

        $pdfBinary = (new PdfService())->renderHtmlToPdf($html);

        $dir = WRITEPATH . 'uploads/circular_pdfs/' . $id;
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        $filename = 'circular_' . $id . '_v' . $versionId . '.pdf';
        $fullPath = $dir . '/' . $filename;

        file_put_contents($fullPath, $pdfBinary);

        $sha  = hash_file('sha256', $fullPath);
        $size = filesize($fullPath);

        $db->table('circular_versions')
            ->where('id', $versionId)
            ->update([
                'pdf_path'       => 'uploads/circular_pdfs/' . $id . '/' . $filename,
                'pdf_sha256'     => $sha,
                'pdf_size_bytes' => $size,
            ]);

        return redirect()->back()->with('success', 'PDF generated.');
    }

    public function download($id)
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $id = (int) $id;
        $db = db_connect();

        $c = $db->table('circulars')->where('id', $id)->get()->getRowArray();
        if (! $c) {
            return redirect()->back()->with('error', 'Circular not found.');
        }

        $versionId = (int) ($c['latest_published_version_id'] ?? 0);
        if ($versionId <= 0) {
            return redirect()->back()->with('error', 'No published version found.');
        }

        $v = $db->table('circular_versions')->where('id', $versionId)->get()->getRowArray();
        if (! $v || empty($v['pdf_path'])) {
            return redirect()->back()->with('error', 'PDF not generated yet.');
        }

        try {
            $fullPath = $this->writablePath((string) $v['pdf_path']);
        } catch (\RuntimeException $e) {
            return redirect()->back()->with('error', 'Invalid file path.');
        }

        if (! is_file($fullPath)) {
            return redirect()->back()->with('error', 'PDF file not found on server.');
        }

        return $this->response->download($fullPath, null);
    }
}
