<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\OfficeModel;
use App\Services\UserProvisioningService;

class ZoneOfficeUserController extends BaseController
{
    public function create()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $officeModel = new OfficeModel();

        // Typically zone offices are type=ZONE
        $zones = $officeModel->where('office_type', 'ZONE')
            ->where('is_active', 1)
            ->orderBy('name', 'ASC')
            ->findAll();

        return view('admin/zone_users/create', [
            'title' => 'Create Zone Office User',
            'zones' => $zones,
        ]);
    }

    public function store()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $data = $this->request->getPost([
            'office_id',
            'username',
            'email',
            'password',
        ]);

        $service = new UserProvisioningService();
        $service->createZoneOfficeUser($data);

        return redirect()
            ->to('/admin/offices')
            ->with('success', 'Zone Office user created and assigned.');
    }
}
