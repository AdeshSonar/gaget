<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;
use App\Models\OfficeModel;

class EmployeeController extends BaseController
{
    public function index()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $db = db_connect();

        $rows = $db->table('employees e')
            ->select('e.id, e.employee_id, e.full_name, e.designation, e.email, e.mobile, e.is_active, o.name as office_name, o.code as office_code')
            ->join('offices o', 'o.id = e.office_id', 'left')
            ->orderBy('e.full_name', 'ASC')
            ->get()
            ->getResultArray();

        return view('admin/employees/index', [
            'title'     => 'Employees',
            'employees' => $rows,
        ]);
    }

    public function create()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $officeModel = new OfficeModel();
        $offices = $officeModel->where('is_active', 1)->orderBy('name', 'ASC')->findAll();

        return view('admin/employees/create', [
            'title'   => 'Add Employee',
            'offices' => $offices,
        ]);
    }

    public function store()
    {
        helper('auth');

        if (! auth()->user()->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $data = $this->request->getPost([
            'employee_id',
            'full_name',
            'office_id',
            'designation',
            'email',
            'mobile',
        ]);

        $data['office_id'] = empty($data['office_id']) ? null : (int) $data['office_id'];

        $model = new EmployeeModel();
        $model->insert($data);

        return redirect()
            ->to('/admin/employees')
            ->with('success', 'Employee added');
    }
}
