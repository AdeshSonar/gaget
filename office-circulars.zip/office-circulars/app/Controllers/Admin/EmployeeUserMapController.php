<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\EmployeeModel;
use App\Models\UserModel;


class EmployeeUserMapController extends BaseController
{
    public function create()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $users = (new UserModel())->findAll();
        $employees = (new EmployeeModel())->where('is_active', 1)->orderBy('full_name', 'ASC')->findAll();

        return view('admin/employee_users/map', [
            'title'     => 'Map Employee User',
            'users'     => $users,
            'employees' => $employees,
        ]);
    }

    public function store()
    {
        helper('auth');

        $user = auth()->user();
        if (! $user->inGroup('admin')) {
            return redirect()->to('/dashboard');
        }

        $userId = (int) $this->request->getPost('user_id');
        $employeeId = (int) $this->request->getPost('employee_ref_id');

        $userModel = new UserModel();
        $userModel->update($userId, [
            'employee_ref_id' => $employeeId,
        ]);

        return redirect()->back()->with('success', 'Mapping saved.');
    }
}
