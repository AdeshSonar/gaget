<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class CircularTemplates extends BaseConfig
{
    public array $templates = [
        'transfer_v1' => [
            'title'         => 'Transfer Order (v1)',
            'document_type' => 'TRANSFER',
            'view'          => 'pdf/templates/transfer_v1',
        ],
    ];
}
