<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Router\RouteCollection;
use Config\Services;

/**
 * @var RouteCollection $routes
 */
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. If you want it, read the docs.
// $routes->setAutoRoute(true);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// Public home
$routes->get('/', 'Home::index');

// Protected dashboard (requires login)
$routes->get('dashboard', 'Dashboard::index', ['filter' => 'session']);

$routes->group('admin', ['filter' => 'session'], function ($routes) {
    $routes->get('document-types', 'Admin\DocumentTypeController::index');
    $routes->get('document-types/create', 'Admin\DocumentTypeController::create');
    $routes->post('document-types/store', 'Admin\DocumentTypeController::store');

    $routes->get('offices', 'Admin\OfficeController::index');
    $routes->get('offices/create', 'Admin\OfficeController::create');
    $routes->post('offices/store', 'Admin\OfficeController::store');

    $routes->get('zone-users/create', 'Admin\ZoneOfficeUserController::create');
    $routes->post('zone-users/store', 'Admin\ZoneOfficeUserController::store');

    $routes->get('employees', 'Admin\EmployeeController::index');
    $routes->get('employees/create', 'Admin\EmployeeController::create');
    $routes->post('employees/store', 'Admin\EmployeeController::store');

    $routes->get('review-queue', 'Admin\CircularReviewController::index');
    $routes->post('circulars/publish/(:num)', 'Admin\CircularReviewController::publish/$1');


    $routes->get('employee-users/map', 'Admin\EmployeeUserMapController::create');
    $routes->post('employee-users/map', 'Admin\EmployeeUserMapController::store');

    // $routes->post('circulars/generate-pdf/(:num)', 'Admin\CircularPdfController::generate/$1');
    // $routes->get('circulars/download/(:num)', 'Admin\CircularPdfController::download/$1');

    

    $routes->get('circulars', 'Admin\CircularAdminController::index');
    $routes->post('circulars/generate-pdf/(:num)', 'Admin\CircularPdfController::generate/$1');
    $routes->get('circulars/download/(:num)', 'Admin\CircularPdfController::download/$1');



});

$routes->group('zone', ['filter' => 'session'], function ($routes) {
    $routes->get('circulars/create', 'Zone\CircularController::create');
    $routes->post('circulars/store', 'Zone\CircularController::store');

    $routes->get('circulars', 'Zone\CircularController::index');
    $routes->post('circulars/submit/(:num)', 'Zone\CircularController::submit/$1');
    $routes->get('circulars/download/(:num)', 'Common\CircularDownloadController::download/$1', ['filter' => 'session']);

});

$routes->group('employee', ['filter' => 'session'], function ($routes) {
    $routes->get('my-circulars', 'Employee\CircularController::myCirculars');
    $routes->get('published-circulars', 'Employee\CircularController::publishedCirculars');
    $routes->get('circulars/download/(:num)', 'Common\CircularDownloadController::download/$1', ['filter' => 'session']);

});


$routes->get('circulars/download/(:num)', 'Common\CircularDownloadController::download/$1', ['filter' => 'session']);


// Shield auth routes (/login, /logout, etc.)
service('auth')->routes($routes);

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * 
 * You can add environment-based routes here if needed.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
