<?php

declare(strict_types=1);

/**
 * This file is part of CodeIgniter Shield.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace Config;

use CodeIgniter\Shield\Config\AuthGroups as ShieldAuthGroups;

class AuthGroups extends ShieldAuthGroups
{
    /**
     * --------------------------------------------------------------------
     * Default Group
     * --------------------------------------------------------------------
     * The group that a newly registered user is added to.
     *
     * For this system we default to "employee". If you later disable self-registration,
     * this default is mostly irrelevant, but it's still a safe default.
     */
    public string $defaultGroup = 'employee';

    /**
     * --------------------------------------------------------------------
     * Groups
     * --------------------------------------------------------------------
     * Roles for the circular system.
     *
     * @var array<string, array<string, string>>
     */
    public array $groups = [
        'admin' => [
            'title'       => 'Admin',
            'description' => 'Approving/Publishing Authority (full access).',
        ],
        'zone_office' => [
            'title'       => 'Zone Office',
            'description' => 'Drafting Authority (creates and submits drafts).',
        ],
        'employee' => [
            'title'       => 'Employee',
            'description' => 'Viewer (My Circulars + All Published Circulars).',
        ],
    ];

    /**
     * --------------------------------------------------------------------
     * Permissions
     * --------------------------------------------------------------------
     * Fine-grained permissions. If a permission is not listed here it cannot be used.
     */
    public array $permissions = [
        // Circular lifecycle
        'circular.create'             => 'Create circular drafts',
        'circular.update_draft'       => 'Edit drafts (own or allowed scope)',
        'circular.submit'             => 'Submit drafts for review',
        'circular.review'             => 'Review submitted drafts (admin)',
        'circular.request_changes'    => 'Send back for changes (admin)',
        'circular.publish'            => 'Approve and publish circulars (admin)',
        'circular.edit_published'     => 'Edit published circulars (creates new version) (admin)',
        'circular.void'               => 'Void/withdraw a circular (admin)',

        // Viewing
        'circular.view_my'            => 'View circulars linked to the logged-in employee',
        'circular.view_published_all' => 'View all published/internal circulars',
        'circular.view_all'           => 'View all circulars across statuses (admin)',

        // Templates & Masters
        'template.manage'             => 'Manage templates/formats',
        'document_type.manage'        => 'Manage document types',
        'office.manage'               => 'Manage offices/zones',

        // User & security administration
        'user.manage'                 => 'Manage users and role assignments',
        'audit.view'                  => 'View audit logs',
    ];

    /**
     * --------------------------------------------------------------------
     * Permissions Matrix
     * --------------------------------------------------------------------
     * Maps permissions to groups (role-level permissions).
     */
    public array $matrix = [
        // Admin: everything
        'admin' => [
            'circular.*',
            'template.manage',
            'document_type.manage',
            'office.manage',
            'user.manage',
            'audit.view',
            'circular.view_published_all',
            'circular.view_all',
        ],

        // Zone Office: drafts + submit + preview + view published
        'zone_office' => [
            'circular.create',
            'circular.update_draft',
            'circular.submit',
            'circular.view_published_all',
        ],

        // Employee: view own + view all published
        'employee' => [
            'circular.view_my',
            'circular.view_published_all',
        ],
    ];
}
