<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
    .watermark {
      position: fixed;
      top: 40%;
      left: 10%;
      width: 80%;
      text-align: center;
      font-size: 80px;
      color: rgba(150,150,150,0.25);
      transform: rotate(-20deg);
      z-index: 0;
    }
    .content { position: relative; z-index: 1; }
    .header { text-align: center; margin-bottom: 12px; }
    .title { font-size: 16px; font-weight: bold; }
    .meta { margin-top: 6px; }
    table { width: 100%; border-collapse: collapse; margin-top: 12px; }
    td, th { border: 1px solid #333; padding: 6px; vertical-align: top; }
    .small { font-size: 11px; color: #333; }
  </style>
</head>
<body>

<?php if (!empty($watermark_text)): ?>
  <div class="watermark"><?= esc($watermark_text) ?></div>
<?php endif; ?>

<div class="content">
  <div class="header">
    <div class="title"><?= esc($meta['title'] ?? 'Transfer Order') ?></div>
    <div class="meta small">
      Type: <?= esc($meta['document_type'] ?? '') ?> |
      Origin: <?= esc($meta['origin_office'] ?? '') ?>
    </div>
    <div class="meta small">
      Published By: <?= esc($meta['published_by'] ?? '') ?> |
      Published At: <?= esc($meta['published_at'] ?? '') ?>
    </div>
    <div class="meta small">
      Circular No: <?= esc($meta['circular_no'] ?? '-') ?>
    </div>
  </div>

  <table>
    <tr>
      <th width="25%">Subject</th>
      <td><?= esc($payload['subject'] ?? '-') ?></td>
    </tr>
    <tr>
      <th>Order Text</th>
      <td style="white-space: pre-wrap;"><?= esc($payload['body'] ?? '-') ?></td>
    </tr>
    <tr>
      <th>Effective Date</th>
      <td><?= esc($payload['effective_date'] ?? '-') ?></td>
    </tr>
    <tr>
      <th>Recipients</th>
      <td><?= esc((string)($meta['recipients_count'] ?? 0)) ?></td>
    </tr>
    <tr>
      <th>Template Key</th>
      <td><?= esc($payload['template_key'] ?? '-') ?></td>
    </tr>
  </table>

  <div class="small" style="margin-top: 12px;">
    System-generated document.
  </div>
</div>

</body>
</html>
