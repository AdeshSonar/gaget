<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm col-md-7">
  <h1 class="h5 mb-3">Create Zone Office User</h1>

  <form method="post" action="/admin/zone-users/store">
    <?= csrf_field() ?>

    <div class="mb-3">
      <label class="form-label">Zone Office</label>
      <select class="form-select" name="office_id" required>
        <option value="">-- Select Zone --</option>
        <?php foreach ($zones as $z): ?>
          <option value="<?= (int) $z['id'] ?>">
            <?= esc($z['name']) ?> (<?= esc($z['code']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Username</label>
      <input class="form-control" type="text" name="username" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Email</label>
      <input class="form-control" type="email" name="email" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Password</label>
      <input class="form-control" type="password" name="password" required>
    </div>

    <button class="btn btn-primary">Create</button>
    <a class="btn btn-secondary" href="/admin/offices">Back</a>
  </form>
</div>
<?= $this->endSection() ?>
