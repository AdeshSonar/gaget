<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
    <div class="d-flex justify-content-between mb-3">
        <h1 class="h5">Document Types</h1>
        <a href="/admin/document-types/create" class="btn btn-sm btn-primary">
            Add
        </a>
    </div>

    <table class="table table-bordered table-sm">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Code</th>
                <th>Name</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($types as $i => $t): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= esc($t['code']) ?></td>
                <td><?= esc($t['name']) ?></td>
                <td><?= $t['is_active'] ? 'Active' : 'Inactive' ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
