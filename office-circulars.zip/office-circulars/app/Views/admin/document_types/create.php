<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm col-md-6">
    <h1 class="h5 mb-3">Add Document Type</h1>

    <form method="post" action="/admin/document-types/store">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label class="form-label">Code</label>
            <input type="text" name="code" class="form-control" required>
            <div class="form-text">Example: TRANSFER, AWARD</div>
        </div>

        <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <button class="btn btn-primary">Save</button>
        <a href="/admin/document-types" class="btn btn-secondary">Back</a>
    </form>
</div>
<?= $this->endSection() ?>
