<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm col-md-6">
    <h1 class="h5 mb-3">Add Office</h1>

    <form method="post" action="/admin/offices/store">
        <?= csrf_field() ?>

        <div class="mb-3">
            <label class="form-label">Office Type</label>
            <select name="office_type" class="form-select" required>
                <option value="HQ">HQ</option>
                <option value="ZONE">ZONE</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Code</label>
            <input type="text" name="code" class="form-control" required>
            <div class="form-text">Example: HQ, ZONE_PUNE, ZONE_NASHIK</div>
        </div>

        <div class="mb-3">
            <label class="form-label">Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Parent (optional)</label>
            <select name="parent_id" class="form-select">
                <option value="">-- None --</option>
                <?php foreach ($parents as $p): ?>
                    <option value="<?= (int) $p['id'] ?>">
                        <?= esc($p['name']) ?> (<?= esc($p['code']) ?>)
                    </option>
                <?php endforeach ?>
            </select>
            <div class="form-text">For ZONE, select HQ as parent if applicable.</div>
        </div>

        <button class="btn btn-primary">Save</button>
        <a href="/admin/offices" class="btn btn-secondary">Back</a>
    </form>
</div>
<?= $this->endSection() ?>
