<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
    <div class="d-flex justify-content-between mb-3">
        <h1 class="h5">Offices</h1>
        <a href="/admin/offices/create" class="btn btn-sm btn-primary">Add</a>
    </div>

    <table class="table table-bordered table-sm">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Type</th>
                <th>Code</th>
                <th>Name</th>
                <th>Parent</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($offices as $i => $o): ?>
            <tr>
                <td><?= $i + 1 ?></td>
                <td><?= esc($o['office_type']) ?></td>
                <td><?= esc($o['code']) ?></td>
                <td><?= esc($o['name']) ?></td>
                <td>
                <?php if (!empty($o['parent_id'])): ?>
                    <?= esc($o['parent_name'] ?? '') ?> (<?= esc($o['parent_code'] ?? '') ?>)
                <?php else: ?>
                    -
                <?php endif; ?>
                </td>

                <td><?= $o['is_active'] ? 'Active' : 'Inactive' ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>

    <div class="text-muted small">
        Note: Parent currently shows parent_id for MVP. Next we can show parent name via join.
    </div>
</div>
<?= $this->endSection() ?>
