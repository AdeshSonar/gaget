<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm col-md-8">
  <h1 class="h5 mb-3">Map Employee Login to Employee Record</h1>

  <form method="post" action="/admin/employee-users/map">
    <?= csrf_field() ?>

    <div class="mb-3">
      <label class="form-label">Employee Login (Shield User)</label>
      <select class="form-select" name="user_id" required>
        <option value="">-- Select User --</option>
        <?php foreach ($users as $u): ?>
          <option value="<?= (int)$u->id ?>">
            <?= esc($u->username ?? ('user#' . $u->id)) ?> (<?= esc($u->getEmail() ?? '') ?>)
          </option>
        <?php endforeach; ?>
      </select>
      <div class="form-text">Choose the login account that belongs to an employee.</div>
    </div>

    <div class="mb-3">
      <label class="form-label">Employee Record</label>
      <select class="form-select" name="employee_ref_id" required>
        <option value="">-- Select Employee --</option>
        <?php foreach ($employees as $e): ?>
          <option value="<?= (int)$e['id'] ?>">
            <?= esc($e['full_name']) ?> (<?= esc($e['employee_id']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <button class="btn btn-primary">Save Mapping</button>
    <a class="btn btn-secondary" href="/dashboard">Back</a>
  </form>
</div>
<?= $this->endSection() ?>
