<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<div class="card oc-card shadow-sm">
  <div class="card-header bg-white py-3">
    <div class="fw-semibold">Review Queue</div>
    <div class="text-muted small">Circulars waiting for admin approval.</div>
  </div>

  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-bordered mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Type</th>
            <th>Origin Office</th>
            <th>Submitted At</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($circulars)): ?>
          <tr>
            <td colspan="7" class="text-center text-muted py-4">
              No items in the review queue.
            </td>
          </tr>
        <?php endif; ?>

        <?php foreach ($circulars as $i => $c): ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td><?= esc($c['title']) ?></td>
            <td><?= esc($c['document_type'] ?? '-') ?></td>
            <td><?= esc($c['origin_office'] ?? '-') ?></td>
            <td><?= esc($c['submitted_at'] ?? '-') ?></td>
            <td><span class="badge bg-warning text-dark"><?= esc($c['status']) ?></span></td>
            <td>
              <form method="post" action="/admin/circulars/publish/<?= (int)$c['id'] ?>" onsubmit="return confirm('Publish this circular?');" class="m-0">
                <?= csrf_field() ?>
                <button class="btn btn-sm btn-success"><i class="bi bi-check2-circle me-1"></i>Publish</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
