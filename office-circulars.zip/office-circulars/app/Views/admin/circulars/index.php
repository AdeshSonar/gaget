<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h5 mb-0">All Circulars</h1>
  </div>

  <table class="table table-bordered table-sm">
    <thead class="table-light">
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Type</th>
        <th>Origin</th>
        <th>Status</th>
        <th>Published</th>
        <th>PDF</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($circulars as $i => $c): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= esc($c['title']) ?></td>
        <td><?= esc($c['document_type'] ?? '-') ?></td>
        <td><?= esc($c['origin_office'] ?? '-') ?></td>
        <td><span class="badge bg-secondary"><?= esc($c['status']) ?></span></td>
        <td><?= esc($c['published_at'] ?? '-') ?></td>
        <td>
          <?php if ($c['status'] === 'PUBLISHED'): ?>
            <div class="d-flex gap-2">
              <form method="post" action="/admin/circulars/generate-pdf/<?= (int)$c['id'] ?>" onsubmit="return confirm('Generate PDF for this circular?');">
                <?= csrf_field() ?>
                <button class="btn btn-sm btn-outline-primary">Generate</button>
              </form>

              <?php if (!empty($c['pdf_path'])): ?>
                <a class="btn btn-sm btn-success" href="/admin/circulars/download/<?= (int)$c['id'] ?>">Download</a>
              <?php else: ?>
                <button class="btn btn-sm btn-secondary" disabled>Download</button>
              <?php endif; ?>
            </div>
          <?php else: ?>
            -
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= $this->endSection() ?>
