<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
  <div class="d-flex justify-content-between mb-3">
    <h1 class="h5">Employees</h1>
    <a href="/admin/employees/create" class="btn btn-sm btn-primary">Add</a>
  </div>

  <table class="table table-bordered table-sm">
    <thead class="table-light">
      <tr>
        <th>#</th>
        <th>Employee ID</th>
        <th>Name</th>
        <th>Office</th>
        <th>Designation</th>
        <th>Status</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($employees as $i => $e): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= esc($e['employee_id']) ?></td>
        <td><?= esc($e['full_name']) ?></td>
        <td>
          <?= esc($e['office_name'] ?? '-') ?>
          <?php if (!empty($e['office_code'])): ?>
            (<?= esc($e['office_code']) ?>)
          <?php endif; ?>
        </td>
        <td><?= esc($e['designation'] ?? '-') ?></td>
        <td><?= $e['is_active'] ? 'Active' : 'Inactive' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= $this->endSection() ?>
