<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm col-md-7">
  <h1 class="h5 mb-3">Add Employee</h1>

  <form method="post" action="/admin/employees/store">
    <?= csrf_field() ?>

    <div class="mb-3">
      <label class="form-label">Employee ID</label>
      <input class="form-control" type="text" name="employee_id" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Full Name</label>
      <input class="form-control" type="text" name="full_name" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Office</label>
      <select class="form-select" name="office_id">
        <option value="">-- Select Office --</option>
        <?php foreach ($offices as $o): ?>
          <option value="<?= (int) $o['id'] ?>">
            <?= esc($o['name']) ?> (<?= esc($o['code']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Designation</label>
      <input class="form-control" type="text" name="designation">
    </div>

    <div class="mb-3">
      <label class="form-label">Email</label>
      <input class="form-control" type="email" name="email">
    </div>

    <div class="mb-3">
      <label class="form-label">Mobile</label>
      <input class="form-control" type="text" name="mobile">
    </div>

    <button class="btn btn-primary">Save</button>
    <a class="btn btn-secondary" href="/admin/employees">Back</a>
  </form>
</div>
<?= $this->endSection() ?>
