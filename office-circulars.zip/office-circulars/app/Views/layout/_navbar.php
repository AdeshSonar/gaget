<?php
// Navbar partial used by layout/main.php
// Uses Shield auth helper (autoloaded in app/Config/Autoload.php)

$loggedIn = function_exists('auth') && auth()->loggedIn();
$user     = $loggedIn ? auth()->user() : null;

$role = null;
if ($user) {
    if ($user->inGroup('admin')) {
        $role = 'admin';
    } elseif ($user->inGroup('zone_office')) {
        $role = 'zone_office';
    } else {
        $role = 'employee';
    }
}

$displayName = $user
    ? (trim((string) ($user->username ?? '')) !== '' ? (string) $user->username : ('User #' . (string) $user->id))
    : null;

$brandHref = $loggedIn ? '/dashboard' : '/';
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center gap-2" href="<?= esc($brandHref) ?>">
      <i class="bi bi-file-earmark-text"></i>
      <span>Office Circulars</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#appNavbar" aria-controls="appNavbar" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="appNavbar">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <?php if ($loggedIn): ?>
          <li class="nav-item">
            <a class="nav-link" href="/dashboard"><i class="bi bi-speedometer2 me-1"></i>Dashboard</a>
          </li>

          <?php if ($role === 'admin'): ?>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-gear me-1"></i>Admin
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="/admin/review-queue">Review Queue</a></li>
                <li><a class="dropdown-item" href="/admin/circulars">All Circulars</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="/admin/document-types">Document Types</a></li>
                <li><a class="dropdown-item" href="/admin/offices">Offices</a></li>
                <li><a class="dropdown-item" href="/admin/employees">Employees</a></li>
                <li><a class="dropdown-item" href="/admin/zone-users/create">Create Zone User</a></li>
                <li><a class="dropdown-item" href="/admin/employee-users/map">Map Employee User</a></li>
              </ul>
            </li>
          <?php elseif ($role === 'zone_office'): ?>
            <li class="nav-item">
              <a class="nav-link" href="/zone/circulars/create"><i class="bi bi-plus-circle me-1"></i>Create Draft</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/zone/circulars"><i class="bi bi-journal-text me-1"></i>My Circulars</a>
            </li>
          <?php else: ?>
            <li class="nav-item">
              <a class="nav-link" href="/employee/my-circulars"><i class="bi bi-person-lines-fill me-1"></i>My Circulars</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="/employee/published-circulars"><i class="bi bi-broadcast me-1"></i>Published</a>
            </li>
          <?php endif; ?>
        <?php endif; ?>
      </ul>

      <div class="d-flex align-items-center gap-2">
        <?php if (! $loggedIn): ?>
          <a class="btn btn-outline-light btn-sm" href="/login"><i class="bi bi-box-arrow-in-right me-1"></i>Login</a>
          <?php if (config('Auth')->allowRegistration): ?>
            <a class="btn btn-warning btn-sm" href="/register"><i class="bi bi-person-plus me-1"></i>Register</a>
          <?php endif; ?>
        <?php else: ?>
          <div class="dropdown">
            <button class="btn btn-outline-light btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-person-circle me-1"></i><?= esc($displayName) ?>
            </button>
            <ul class="dropdown-menu dropdown-menu-end">
              <li>
                <span class="dropdown-item-text small text-muted">
                  Role: <span class="badge text-bg-secondary ms-1"><?= esc($role) ?></span>
                </span>
              </li>
              <li><hr class="dropdown-divider"></li>
              <li>
                <a class="dropdown-item text-danger" href="/logout" onclick="return confirm('Logout now?');">
                  <i class="bi bi-box-arrow-right me-1"></i>Logout
                </a>
              </li>
            </ul>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
