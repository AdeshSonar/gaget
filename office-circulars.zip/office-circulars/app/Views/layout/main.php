<?php
/**
 * Main application layout.
 *
 * Notes:
 * - We read flashdata directly from session so controllers don't need to pass variables.
 * - We include a navbar partial that shows Login/Logout based on Shield session.
 */


$message = session()->getFlashdata('message');
$success = session()->getFlashdata('success');
$error   = session()->getFlashdata('error');
$warning = session()->getFlashdata('warning');
$info    = session()->getFlashdata('info');

if (empty($info) && !empty($message)) {
  $info = $message; // show Shield success logout/login messages nicely
}


if (empty($info) && !empty($message)) {
  $info = $message; // show Shield success logout/login messages nicely
}


// Common CI4 pattern: validation errors are sometimes stored in session('errors')
$errors = session('errors');
if (! is_array($errors)) {
  $errors = [];
}
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= esc($title ?? 'Office Circulars') ?></title>

  <!-- Bootstrap + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

  <!-- App styles -->
  <link href="/assets/css/app.css" rel="stylesheet">
  <?= $this->renderSection('styles') ?>
</head>

<body class="bg-body-tertiary d-flex flex-column min-vh-100">

  <?= $this->include('layout/_navbar') ?>

  <main class="container my-4 flex-grow-1">

    <?php if (! empty($errors)): ?>
      <div class="alert alert-danger" role="alert">
        <div class="fw-semibold mb-1">Please fix the following:</div>
        <ul class="mb-0">
          <?php foreach ($errors as $msg): ?>
            <li><?= esc($msg) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <?php if (! empty($success)): ?>
      <div class="alert alert-success" role="alert">
        <i class="bi bi-check-circle me-1"></i><?= esc($success) ?>
      </div>
    <?php endif; ?>

    <?php if (! empty($error)): ?>
      <div class="alert alert-danger" role="alert">
        <i class="bi bi-exclamation-triangle me-1"></i><?= esc($error) ?>
      </div>
    <?php endif; ?>

    <?php if (! empty($warning)): ?>
      <div class="alert alert-warning" role="alert">
        <i class="bi bi-exclamation-circle me-1"></i><?= esc($warning) ?>
      </div>
    <?php endif; ?>

    <?php if (! empty($info)): ?>
      <div class="alert alert-info" role="alert">
        <i class="bi bi-info-circle me-1"></i><?= esc($info) ?>
      </div>
    <?php endif; ?>

    <?= $this->renderSection('content') ?>
  </main>

  <footer class="border-top bg-white">
    <div class="container py-3 small text-muted d-flex flex-wrap justify-content-between align-items-center">
      <div>Office Circulars • <?= date('Y') ?></div>
      <div class="d-flex gap-3">
        <a class="link-secondary text-decoration-none" href="/">Home</a>
        <?php if (function_exists('auth') && auth()->loggedIn()): ?>
          <a class="link-secondary text-decoration-none" href="/dashboard">Dashboard</a>
        <?php endif; ?>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <?= $this->renderSection('scripts') ?>
</body>
</html>
