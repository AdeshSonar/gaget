<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<?php $loggedIn = function_exists('auth') && auth()->loggedIn(); ?>

<div class="row g-4 align-items-stretch">
  <div class="col-lg-7">
    <div class="card oc-card shadow-sm h-100">
      <div class="card-body p-4 p-lg-5">
        <h1 class="h3 mb-2">Office Circulars</h1>
        <p class="text-muted mb-4">
          Create, review, publish, and distribute office circulars with role-based access.
        </p>

        <div class="d-flex flex-wrap gap-2">
          <?php if ($loggedIn): ?>
            <a class="btn btn-primary" href="/dashboard">
              <i class="bi bi-speedometer2 me-1"></i>Go to Dashboard
            </a>
            <a class="btn btn-outline-secondary" href="/logout" onclick="return confirm('Logout now?');">
              <i class="bi bi-box-arrow-right me-1"></i>Logout
            </a>
          <?php else: ?>
            <a class="btn btn-primary" href="/login">
              <i class="bi bi-box-arrow-in-right me-1"></i>Login
            </a>
            <?php if (config('Auth')->allowRegistration): ?>
              <a class="btn btn-outline-secondary" href="/register">
                <i class="bi bi-person-plus me-1"></i>Register
              </a>
            <?php endif; ?>
          <?php endif; ?>
        </div>

        <hr class="my-4">

        <div class="row g-3">
          <div class="col-md-6">
            <div class="d-flex gap-3">
              <div class="text-primary fs-4"><i class="bi bi-shield-lock"></i></div>
              <div>
                <div class="fw-semibold">Role-based access</div>
                <div class="text-muted small">Admin, Zone Office, Employee views.</div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="d-flex gap-3">
              <div class="text-primary fs-4"><i class="bi bi-diagram-3"></i></div>
              <div>
                <div class="fw-semibold">Workflow</div>
                <div class="text-muted small">Draft → Review → Published.</div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="d-flex gap-3">
              <div class="text-primary fs-4"><i class="bi bi-filetype-pdf"></i></div>
              <div>
                <div class="fw-semibold">PDF generation</div>
                <div class="text-muted small">Generate and download published circulars.</div>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="d-flex gap-3">
              <div class="text-primary fs-4"><i class="bi bi-activity"></i></div>
              <div>
                <div class="fw-semibold">Audit trail</div>
                <div class="text-muted small">Workflow events logged server-side.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card oc-card shadow-sm h-100">
      <div class="card-header py-3">
        <div class="fw-semibold">Quick start</div>
      </div>
      <div class="card-body p-4">
        <ol class="mb-0">
          <li class="mb-2">Login as Zone Office.</li>
          <li class="mb-2">Create a draft circular and select recipients.</li>
          <li class="mb-2">Submit for review.</li>
          <li class="mb-2">Admin publishes and generates the PDF.</li>
          <li>Employees download from “Published Circulars”.</li>
        </ol>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
