<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
  <div class="p-4 bg-white rounded shadow-sm">
    <h1 class="h4 mb-2">Office Circulars</h1>
    <p class="mb-0">Foundation ready. Next: Auth + Roles + Dashboards.</p>
  </div>
<?= $this->endSection() ?>
