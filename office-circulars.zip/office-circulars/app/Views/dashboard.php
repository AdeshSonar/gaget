<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
  <div class="p-4 bg-white rounded shadow-sm">
    <h1 class="h5 mb-3">Dashboard</h1>

    <div class="mb-2">
      Logged in as: <strong><?= esc($user->username ?? (string) $user->id) ?></strong>
    </div>

    <div class="mb-4">
      Role: <span class="badge bg-primary"><?= esc($role) ?></span>
    </div>

    <?php if ($role === 'admin'): ?>

      <div class="row g-3 mb-3">
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/document-types">Document Types</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/offices">Offices</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/zone-users/create">Create Zone Office User</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/employees">Employees</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/review-queue">Review Queue</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/employee-users/map">Map Employee User</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/admin/circulars">All Circulars</a>
        </div>

        
      </div>

      <div class="alert alert-info mb-0">
        Admin dashboard placeholder. Next we’ll add: Review Queue, All Circulars, Masters (Templates, Offices, Users).
      </div>

    <?php elseif ($role === 'zone_office'): ?>

      <div class="row g-3 mb-3">
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/zone/circulars/create">Create Draft Circular</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/zone/circulars">My Circulars</a>
        </div>
      </div>

      <div class="alert alert-info mb-0">
        Zone Office dashboard placeholder. Next we’ll add: My Drafts, Create Draft, Submitted.
      </div>

    <?php else: ?>

      <!-- Employee Section -->
      <div class="row g-3 mb-3">
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/employee/my-circulars">My Circulars</a>
        </div>
        <div class="col-md-4">
          <a class="btn btn-outline-primary w-100" href="/employee/published-circulars">All Published Circulars</a>
        </div>
      </div>

      <div class="alert alert-info mb-0">
        Employee dashboard placeholder. Next we’ll add: My Circulars and All Published Circulars.
      </div>

    <?php endif; ?>
  </div>
<?= $this->endSection() ?>
