<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<?php
  $name = trim((string) ($user->username ?? ''));
  if ($name === '') {
    $name = 'User #' . (string) ($user->id ?? '');
  }

  $roleLabel = $role ?? 'employee';
  $roleIcon = 'bi-person-check';
  if ($roleLabel === 'admin') {
    $roleIcon = 'bi-shield-lock';
  } elseif ($roleLabel === 'zone_office') {
    $roleIcon = 'bi-buildings';
  }
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
  <div>
    <h1 class="h4 mb-1">Dashboard</h1>
    <div class="text-muted">
      Signed in as <span class="fw-semibold"><?= esc($name) ?></span>
      <span class="mx-2">•</span>
      <span class="badge text-bg-secondary"><i class="bi <?= esc($roleIcon) ?> me-1"></i><?= esc($roleLabel) ?></span>
    </div>
  </div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary" href="/" title="Home"><i class="bi bi-house"></i></a>
    <a class="btn btn-outline-danger" href="/logout" onclick="return confirm('Logout now?');">
      <i class="bi bi-box-arrow-right me-1"></i>Logout
    </a>
  </div>
</div>

<?php if ($roleLabel === 'admin'): ?>

  <div class="row g-3">
    <div class="col-md-6 col-lg-4">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/admin/review-queue">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-inbox"></i></div>
            <div>
              <div class="fw-semibold">Review Queue</div>
              <div class="text-muted small">Approve and publish submissions.</div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-md-6 col-lg-4">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/admin/circulars">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-journal-text"></i></div>
            <div>
              <div class="fw-semibold">All Circulars</div>
              <div class="text-muted small">Generate PDFs & downloads.</div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-md-6 col-lg-4">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/admin/document-types">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-tags"></i></div>
            <div>
              <div class="fw-semibold">Document Types</div>
              <div class="text-muted small">Manage codes & categories.</div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-md-6 col-lg-4">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/admin/offices">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-building"></i></div>
            <div>
              <div class="fw-semibold">Offices</div>
              <div class="text-muted small">Zones, HQ, and mappings.</div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-md-6 col-lg-4">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/admin/employees">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-people"></i></div>
            <div>
              <div class="fw-semibold">Employees</div>
              <div class="text-muted small">Add and manage recipients.</div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <div class="col-md-6 col-lg-4">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/admin/zone-users/create">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-person-gear"></i></div>
            <div>
              <div class="fw-semibold">Zone Users</div>
              <div class="text-muted small">Create zone office logins.</div>
            </div>
          </div>
        </div>
      </a>
    </div>
  </div>

<?php elseif ($roleLabel === 'zone_office'): ?>

  <div class="row g-3">
    <div class="col-md-6">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/zone/circulars/create">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-plus-circle"></i></div>
            <div>
              <div class="fw-semibold">Create Draft Circular</div>
              <div class="text-muted small">Build a new draft for your office.</div>
            </div>
          </div>
        </div>
      </a>
    </div>
    <div class="col-md-6">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/zone/circulars">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-journal-text"></i></div>
            <div>
              <div class="fw-semibold">My Circulars</div>
              <div class="text-muted small">Track drafts and submissions.</div>
            </div>
          </div>
        </div>
      </a>
    </div>
  </div>

<?php else: ?>

  <div class="row g-3">
    <div class="col-md-6">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/employee/my-circulars">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-person-lines-fill"></i></div>
            <div>
              <div class="fw-semibold">My Circulars</div>
              <div class="text-muted small">Circulars addressed to you.</div>
            </div>
          </div>
        </div>
      </a>
    </div>
    <div class="col-md-6">
      <a class="card oc-card shadow-sm text-decoration-none h-100" href="/employee/published-circulars">
        <div class="card-body">
          <div class="d-flex align-items-center gap-3">
            <div class="fs-3 text-primary"><i class="bi bi-broadcast"></i></div>
            <div>
              <div class="fw-semibold">Published Circulars</div>
              <div class="text-muted small">Browse and download PDFs.</div>
            </div>
          </div>
        </div>
      </a>
    </div>
  </div>

<?php endif; ?>

<?= $this->endSection() ?>
