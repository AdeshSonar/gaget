<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
  <h1 class="h5 mb-3">All Published Circulars</h1>

  <table class="table table-bordered table-sm">
    <thead class="table-light">
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Type</th>
        <th>Origin Office</th>
        <th>Published At</th>
        <th>PDF</th>

      </tr>
    </thead>
    <tbody>
    <?php foreach ($circulars as $i => $c): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= esc($c['title']) ?></td>
        <td><?= esc($c['document_type'] ?? '-') ?></td>
        <td><?= esc($c['origin_office'] ?? '-') ?></td>
        <td><?= esc($c['published_at'] ?? '-') ?></td>
        <td>
          <a class="btn btn-sm btn-success" href="/circulars/download/<?= (int)$c['id'] ?>">Download</a>
        </td>

      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= $this->endSection() ?>
