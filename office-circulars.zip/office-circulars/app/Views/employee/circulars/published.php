<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<div class="card oc-card shadow-sm">
  <div class="card-header bg-white py-3">
    <div class="fw-semibold">All Published Circulars</div>
    <div class="text-muted small">Only circulars with generated PDFs can be downloaded.</div>
  </div>

  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-bordered mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Type</th>
            <th>Origin Office</th>
            <th>Published At</th>
            <th>PDF</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($circulars)): ?>
          <tr>
            <td colspan="6" class="text-center text-muted py-4">
              No published circulars available.
            </td>
          </tr>
        <?php endif; ?>

        <?php foreach ($circulars as $i => $c): ?>
          <tr>
            <td class="text-nowrap"><?= $i + 1 ?></td>
            <td class="text-truncate-2" style="max-width: 520px;">
              <?= esc($c['title']) ?>
            </td>
            <td class="text-nowrap"><?= esc($c['document_type'] ?? '-') ?></td>
            <td class="text-nowrap"><?= esc($c['origin_office'] ?? '-') ?></td>
            <td class="text-nowrap"><?= esc($c['published_at'] ?? '-') ?></td>
            <td class="text-nowrap">
              <a class="btn btn-sm btn-success" href="/circulars/download/<?= (int)$c['id'] ?>">
                <i class="bi bi-download me-1"></i>Download
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
