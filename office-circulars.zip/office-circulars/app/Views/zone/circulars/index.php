<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="h5 mb-0">My Circulars (Zone)</h1>
    <a class="btn btn-sm btn-primary" href="/zone/circulars/create">Create Draft</a>
  </div>

  <table class="table table-bordered table-sm">
    <thead class="table-light">
      <tr>
        <th>#</th>
        <th>Title</th>
        <th>Type</th>
        <th>Status</th>
        <th>Created</th>
        <th>Submitted</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($circulars as $i => $c): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><?= esc($c['title']) ?></td>
        <td><?= esc($c['document_type'] ?? '-') ?></td>
        <td><span class="badge bg-secondary"><?= esc($c['status']) ?></span></td>
        <td><?= esc($c['created_at'] ?? '-') ?></td>
        <td><?= esc($c['submitted_at'] ?? '-') ?></td>
        <td>
          <?php if ($c['status'] === 'DRAFT'): ?>
            <form method="post" action="/zone/circulars/submit/<?= (int)$c['id'] ?>" onsubmit="return confirm('Submit for review?');">
              <?= csrf_field() ?>
              <button class="btn btn-sm btn-warning">Submit</button>
            </form>
          <?php else: ?>
            -
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= $this->endSection() ?>
