<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>

<?php
  $badge = function (string $status): string {
    return match ($status) {
      'DRAFT'     => 'bg-secondary',
      'IN_REVIEW' => 'bg-warning text-dark',
      'PUBLISHED' => 'bg-success',
      default     => 'bg-light text-dark',
    };
  };
?>

<div class="card oc-card shadow-sm">
  <div class="card-header bg-white py-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
    <div>
      <div class="fw-semibold">My Circulars (Zone)</div>
      <div class="text-muted small">Drafts created by your office.</div>
    </div>
    <a class="btn btn-sm btn-primary" href="/zone/circulars/create"><i class="bi bi-plus-circle me-1"></i>Create Draft</a>
  </div>

  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover table-bordered mb-0">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Title</th>
            <th>Type</th>
            <th>Status</th>
            <th>Created</th>
            <th>Submitted</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
        <?php if (empty($circulars)): ?>
          <tr>
            <td colspan="7" class="text-center text-muted py-4">
              No circulars yet. Click <strong>Create Draft</strong> to start.
            </td>
          </tr>
        <?php endif; ?>

        <?php foreach ($circulars as $i => $c): ?>
          <tr>
            <td class="text-nowrap"><?= $i + 1 ?></td>
            <td class="text-truncate-2" style="max-width: 420px;">
              <?= esc($c['title']) ?>
            </td>
            <td class="text-nowrap"><?= esc($c['document_type'] ?? '-') ?></td>
            <td class="text-nowrap"><span class="badge <?= esc($badge((string) $c['status'])) ?>"><?= esc($c['status']) ?></span></td>
            <td class="text-nowrap"><?= esc($c['created_at'] ?? '-') ?></td>
            <td class="text-nowrap"><?= esc($c['submitted_at'] ?? '-') ?></td>
            <td class="text-nowrap">
              <?php if (($c['status'] ?? '') === 'DRAFT'): ?>
                <form method="post" action="/zone/circulars/submit/<?= (int)$c['id'] ?>" onsubmit="return confirm('Submit for review?');" class="m-0">
                  <?= csrf_field() ?>
                  <button class="btn btn-sm btn-warning"><i class="bi bi-send me-1"></i>Submit</button>
                </form>
              <?php else: ?>
                <span class="text-muted">-</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
