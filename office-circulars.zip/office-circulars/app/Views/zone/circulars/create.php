<?= $this->extend('layout/main') ?>

<?= $this->section('content') ?>
<div class="bg-white p-4 rounded shadow-sm">
  <h1 class="h5 mb-3">Create Draft Circular</h1>

  <form method="post" action="/zone/circulars/store">
    <?= csrf_field() ?>

    <div class="mb-3">
      <label class="form-label">Document Type</label>
      <select class="form-select" name="document_type_id" required>
        <option value="">-- Select Type --</option>
        <?php foreach ($docTypes as $d): ?>
          <option value="<?= (int) $d['id'] ?>">
            <?= esc($d['name']) ?> (<?= esc($d['code']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="mb-3">
      <label class="form-label">Title</label>
      <input class="form-control" type="text" name="title" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Template Key</label>
      <input
        class="form-control"
        type="text"
        name="template_key"
        value="transfer_v1"
        placeholder="transfer_v1 / award_v1 / etc."
      >
      <div class="form-text">For this step, use <strong>transfer_v1</strong>.</div>
    </div>

    <hr class="my-3">

    <h2 class="h6">Transfer Template Fields (v1)</h2>

    <div class="mb-3">
      <label class="form-label">Subject</label>
      <input class="form-control" type="text" name="payload_subject" placeholder="Subject line">
    </div>

    <div class="mb-3">
      <label class="form-label">Order Body</label>
      <textarea class="form-control" name="payload_body" rows="5" placeholder="Main order text"></textarea>
    </div>

    <div class="mb-3">
      <label class="form-label">Effective Date</label>
      <input class="form-control" type="date" name="payload_effective_date">
    </div>

    <div class="mb-3">
      <label class="form-label">Recipients (select multiple)</label>
      <select class="form-select" name="recipient_ids[]" multiple size="10">
        <?php foreach ($employees as $e): ?>
          <option value="<?= (int) $e['id'] ?>">
            <?= esc($e['full_name']) ?> (<?= esc($e['employee_id']) ?>)
          </option>
        <?php endforeach; ?>
      </select>
      <div class="form-text">Hold Ctrl/Command to select multiple employees.</div>
    </div>

    <button class="btn btn-primary">Create Draft</button>
    <a href="/dashboard" class="btn btn-secondary">Back</a>
  </form>
</div>
<?= $this->endSection() ?>
