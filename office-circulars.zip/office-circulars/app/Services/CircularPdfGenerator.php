<?php

namespace App\Services;

class CircularPdfGenerator
{
    public function generateForPublishedCircular(int $circularId): array
    {
        $db = db_connect();

        $c = $db->table('circulars c')
            ->select('c.*, dt.name as document_type, o.name as origin_office, u.username as published_username')
            ->join('document_types dt', 'dt.id = c.document_type_id', 'left')
            ->join('offices o', 'o.id = c.origin_office_id', 'left')
            ->join('users u', 'u.id = c.published_by', 'left')
            ->where('c.id', $circularId)
            ->get()
            ->getRowArray();

        if (! $c) {
            return ['ok' => false, 'error' => 'Circular not found'];
        }

        if ($c['status'] !== 'PUBLISHED') {
            return ['ok' => false, 'error' => 'Circular is not published'];
        }

        $versionId = (int) ($c['latest_published_version_id'] ?? 0);
        if ($versionId <= 0) {
            return ['ok' => false, 'error' => 'No published version found'];
        }

        $recipientsCount = $db->table('circular_version_recipients')
            ->where('circular_version_id', $versionId)
            ->countAllResults();

        $vrow = $db->table('circular_versions')->where('id', $versionId)->get()->getRowArray();
        if (! $vrow) {
            return ['ok' => false, 'error' => 'Version record not found'];
        }

        $payload = [];
        $tplKey  = $vrow['template_key'] ?? null;

        if (! empty($vrow['payload_json'])) {
            $payload = json_decode($vrow['payload_json'], true) ?: [];
            $tplKey  = $payload['template_key'] ?? $tplKey;
        }

        $config = config('CircularTemplates');
        $tplMeta = (is_object($config) && !empty($tplKey) && isset($config->templates[$tplKey]))
            ? $config->templates[$tplKey]
            : null;

        $view = $tplMeta['view'] ?? 'pdf/circular_basic';

        $html = view($view, [
            'payload' => $payload,
            'meta' => [
                'title'            => $c['title'],
                'document_type'    => $c['document_type'] ?? '',
                'origin_office'    => $c['origin_office'] ?? '',
                'published_by'     => $c['published_username'] ?? 'admin',
                'published_at'     => $c['published_at'] ?? '',
                'circular_no'      => $c['circular_no'] ?? null,
                'recipients_count' => $recipientsCount,
            ],
            'watermark_text' => null,
        ]);

        $pdfBinary = (new PdfService())->renderHtmlToPdf($html);

        $dir = WRITEPATH . 'uploads/circular_pdfs/' . $circularId;
        if (! is_dir($dir)) {
            mkdir($dir, 0775, true);
        }

        $filename = 'circular_' . $circularId . '_v' . $versionId . '.pdf';
        $fullPath = $dir . '/' . $filename;

        file_put_contents($fullPath, $pdfBinary);

        $sha  = hash_file('sha256', $fullPath);
        $size = filesize($fullPath);

        $relPath = 'uploads/circular_pdfs/' . $circularId . '/' . $filename;

        $db->table('circular_versions')
            ->where('id', $versionId)
            ->update([
                'pdf_path'       => $relPath,
                'pdf_sha256'     => $sha,
                'pdf_size_bytes' => $size,
            ]);

        return ['ok' => true, 'version_id' => $versionId, 'pdf_path' => $relPath];
    }
}
