<?php

namespace App\Services;

use CodeIgniter\Shield\Entities\User;
use CodeIgniter\Shield\Models\UserModel;

class UserProvisioningService
{
    /**
     * Creates a Zone Office user, sets office_id, and assigns group zone_office.
     * Returns new user id.
     */
    public function createZoneOfficeUser(array $data): int
    {
        $users = new UserModel();

        // 1) Create user entity
        $user = new User([
            'username'  => $data['username'],
            'office_id' => (int) $data['office_id'], // we added office_id column
        ]);

        // 2) Create email identity + password
        // Shield uses "auth_identities" for login identifiers.
        // Using setEmail()/setPassword() ensures proper hashing and identity setup.
        $user->setEmail($data['email']);
        $user->setPassword($data['password']);

        // 3) Save user
        $users->save($user);

        // Refresh ID (some setups require fetching it)
        $userId = (int) ($user->id ?? $users->getInsertID());

        // 4) Assign group
        $freshUser = $users->findById($userId);
        $freshUser->addGroup('zone_office');

        return $userId;
    }
}
