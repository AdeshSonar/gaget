<?php

namespace App\Models;

use CodeIgniter\Model;

class OfficeModel extends Model
{
    protected $table            = 'offices';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;

    protected $allowedFields = [
        'office_type',
        'code',
        'name',
        'parent_id',
        'is_active',
    ];

    protected $useTimestamps = true;
}
