<?php

namespace App\Models;

use CodeIgniter\Model;

class CircularVersionModel extends Model
{
    protected $table            = 'circular_versions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;

    protected $allowedFields = [
        'circular_id',
        'version_no',
        'source',
        'template_key',
        'payload_json',
        'pdf_path',
        'pdf_sha256',
        'pdf_size_bytes',
        'status_snapshot',
        'created_by',
        'created_at',
    ];

    protected $useTimestamps = false;
}
