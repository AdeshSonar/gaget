<?php

namespace App\Models;

use CodeIgniter\Shield\Models\UserModel as ShieldUserModel;

class UserModel extends ShieldUserModel
{
    /**
     * Include Shield defaults + your custom columns in users table.
     * If a column is missing here, CI will strip it and updates will become empty.
     */
    protected $allowedFields = [
        // Shield user columns (common)
        'username',
        'status',
        'status_message',
        'active',
        'last_active',
        'deleted_at',
        'created_at',
        'updated_at',

        // Your custom columns in users table
        'office_id',
        'employee_ref_id',
    ];
}
