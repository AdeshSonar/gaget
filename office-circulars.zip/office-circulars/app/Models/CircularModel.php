<?php

namespace App\Models;

use CodeIgniter\Model;

class CircularModel extends Model
{
    protected $table            = 'circulars';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;

    protected $allowedFields = [
        'document_type_id',
        'origin_office_id',
        'status',
        'title',
        'circular_no',
        'current_version_id',
        'latest_published_version_id',
        'submitted_at',
        'submitted_by',
        'published_at',
        'published_by',
        'visibility',
        'is_void',
        'void_reason',
    ];

    protected $useTimestamps = true;
}
