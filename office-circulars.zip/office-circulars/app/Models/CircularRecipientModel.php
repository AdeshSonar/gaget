<?php

namespace App\Models;

use CodeIgniter\Model;

class CircularRecipientModel extends Model
{
    protected $table      = 'circular_version_recipients';
    protected $primaryKey = ''; // composite, we won't use Model->save for single row updates

    protected $allowedFields = [
        'circular_version_id',
        'employee_id',
        'created_at',
    ];

    public $useTimestamps = false;
}
