<?php

namespace App\Models;

use CodeIgniter\Model;

class CircularWorkflowEventModel extends Model
{
    protected $table            = 'circular_workflow_events';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;

    protected $allowedFields = [
        'circular_id',
        'event_type',
        'from_status',
        'to_status',
        'actor_user_id',
        'actor_office_id',
        'circular_version_id',
        'ip_address',
        'user_agent',
        'notes',
        'created_at',
    ];

    protected $useTimestamps = false;
}
