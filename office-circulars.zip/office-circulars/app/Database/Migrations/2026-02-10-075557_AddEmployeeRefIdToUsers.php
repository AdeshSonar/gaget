<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddEmployeeRefIdToUsers extends Migration
{
    public function up()
    {
        $fields = [
            'employee_ref_id' => [
                'type'       => 'BIGINT',
                'constraint' => 20,
                'unsigned'   => true,
                'null'       => true,
                'after'      => 'office_id',
            ],
        ];

        $this->forge->addColumn('users', $fields);

        $this->forge->addKey('employee_ref_id');
        $this->forge->addForeignKey('employee_ref_id', 'employees', 'id', 'SET NULL', 'CASCADE');
    }

    public function down()
    {
        $this->forge->dropColumn('users', 'employee_ref_id');
    }
}
