<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateCirculars extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'BIGINT',
                'constraint'     => 20,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'document_type_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'origin_office_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'status' => [
                'type'       => 'VARCHAR',
                'constraint' => 20, // DRAFT, IN_REVIEW, PUBLISHED
                'default'    => 'DRAFT',
            ],
            'title' => [
                'type'       => 'VARCHAR',
                'constraint' => 255,
            ],
            'circular_no' => [
                'type'       => 'VARCHAR',
                'constraint' => 100,
                'null'       => true,
            ],
            'current_version_id' => [
                'type'       => 'BIGINT',
                'constraint' => 20,
                'unsigned'   => true,
                'null'       => true,
            ],
            'latest_published_version_id' => [
                'type'       => 'BIGINT',
                'constraint' => 20,
                'unsigned'   => true,
                'null'       => true,
            ],
            'submitted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'submitted_by' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
            ],
            'published_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'published_by' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
            ],
            'visibility' => [
                'type'       => 'VARCHAR',
                'constraint' => 20, // INTERNAL, PUBLIC (future)
                'default'    => 'INTERNAL',
            ],
            'is_void' => [
                'type'    => 'BOOLEAN',
                'default' => false,
            ],
            'void_reason' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey('id', true);
        $this->forge->addKey(['status', 'document_type_id']);
        $this->forge->addKey('origin_office_id');
        $this->forge->addKey('published_at');
        $this->forge->addUniqueKey('circular_no');

        $this->forge->addForeignKey('document_type_id', 'document_types', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('origin_office_id', 'offices', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('submitted_by', 'users', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('published_by', 'users', 'id', 'SET NULL', 'CASCADE');

        $this->forge->createTable('circulars');
    }

    public function down()
    {
        $this->forge->dropTable('circulars');
    }
}
