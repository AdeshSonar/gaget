<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddOfficeIdToUsers extends Migration
{
    public function up()
    {
        $fields = [
            'office_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
                'after'      => 'id',
            ],
        ];

        $this->forge->addColumn('users', $fields);

        // Index + FK
        $this->forge->addKey('office_id');
        $this->forge->addForeignKey('office_id', 'offices', 'id', 'SET NULL', 'CASCADE');
    }

    public function down()
    {
        // Drop FK safely (CI4 may require explicit constraint name in some setups)
        // If down fails, we can handle it later; for now the focus is forward.
        $this->forge->dropColumn('users', 'office_id');
    }
}
