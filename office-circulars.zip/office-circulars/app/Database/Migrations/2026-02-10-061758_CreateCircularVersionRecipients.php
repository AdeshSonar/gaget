<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateCircularVersionRecipients extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'circular_version_id' => [
                'type'       => 'BIGINT',
                'constraint' => 20,
                'unsigned'   => true,
            ],
            'employee_id' => [
                'type'       => 'BIGINT',
                'constraint' => 20,
                'unsigned'   => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);

        $this->forge->addKey(['circular_version_id', 'employee_id'], true);

        $this->forge->addKey('employee_id');

        $this->forge->addForeignKey('circular_version_id', 'circular_versions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('employee_id', 'employees', 'id', 'RESTRICT', 'CASCADE');

        $this->forge->createTable('circular_version_recipients');
    }

    public function down()
    {
        $this->forge->dropTable('circular_version_recipients');
    }
}
